using Microsoft.AspNetCore.Mvc;

[SessionAuthorize("Organiser")]
public class OrganiserController : Controller
{
    private readonly ApiService _api;

    public OrganiserController(ApiService api)
    {
        _api = api;
    }

    public async Task<IActionResult> Dashboard()
    {
        var events = await _api.GetAsync<List<EventViewModel>>("api/organiser/events");
        return View(events ?? new List<EventViewModel>());
    }

    [HttpPost]
    public async Task<IActionResult> CreateEvent(EventCreateViewModel model, IFormFile? bannerImage)
    {
        if (ModelState.IsValid)
        {
            if (bannerImage != null)
            {
                await _api.UploadImageAsync("api/events/upload-banner", bannerImage, "EventName", model.Name);
            }

            await _api.PostAsync("api/events", model);
            return RedirectToAction(nameof(Dashboard));
        }
        return View(model);
    }
}
