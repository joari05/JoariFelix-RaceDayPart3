using Microsoft.AspNetCore.Mvc;

public class AccountController : Controller
{
    private readonly ApiService _api;

    public AccountController(ApiService api)
    {
        _api = api;
    }

    [HttpGet]
    public IActionResult Login() => View();

    [HttpPost]
    public async Task<IActionResult> Login(string email, string password)
    {
        var loginDto = new { Email = email, Password = password };
        var result = await _api.PostAsync("api/auth/login", loginDto);

        if (result) // Assuming the API validates credentials
        {
            HttpContext.Session.SetString("UserRole", "Participant"); // Or "Organiser" from API response
            HttpContext.Session.SetInt32("UserId", 1);
            return RedirectToAction("Index", "Home");
        }

        ModelState.AddModelError(string.Empty, "Invalid credentials.");
        return View();
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}
