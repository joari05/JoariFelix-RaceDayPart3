public class EnrolmentViewModel
{
    public int Id { get; set; }
    public string EventName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public string Status { get; set; } = "Pending";
}
