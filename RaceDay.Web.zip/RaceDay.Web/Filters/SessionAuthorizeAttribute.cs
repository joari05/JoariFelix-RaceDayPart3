using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

public class SessionAuthorizeAttribute : ActionFilterAttribute
{
    private readonly string[] _allowedRoles;

    public SessionAuthorizeAttribute(params string[] allowedRoles)
    {
        _allowedRoles = allowedRoles;
    }

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        var userRole = context.HttpContext.Session.GetString("UserRole");
        var userId = context.HttpContext.Session.GetInt32("UserId");

        if (userId == null || string.IsNullOrEmpty(userRole))
        {
            context.Result = new RedirectToActionResult("Login", "Account", null);
            return;
        }

        if (_allowedRoles.Length > 0 && !_allowedRoles.Contains(userRole))
        {
            context.Result = new RedirectToActionResult("AccessDenied", "Home", null);
        }
    }
}
