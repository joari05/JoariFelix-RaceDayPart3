using System.Text;
using System.Text.Json;

public class ApiService
{
    private readonly HttpClient _client;

    public ApiService(IHttpClientFactory clientFactory)
    {
        _client = clientFactory.CreateClient("RaceDayApi");
    }

    public async Task<T?> GetAsync<T>(string endpoint)
    {
        var response = await _client.GetAsync(endpoint);
        if (!response.IsSuccessStatusCode) return default;
        
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }

    public async Task<bool> PostAsync<T>(string endpoint, T data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await _client.PostAsync(endpoint, content);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> UploadImageAsync(string endpoint, IFormFile file, string additionalDataName, string additionalDataValue)
    {
        using var formData = new MultipartFormDataContent();
        using var stream = file.OpenReadStream();
        formData.Add(new StreamContent(stream), "file", file.FileName);
        formData.Add(new StringContent(additionalDataValue), additionalDataName);

        var response = await _client.PostAsync(endpoint, formData);
        return response.IsSuccessStatusCode;
    }
}
